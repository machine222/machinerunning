import PurchasePage from "@/components/purchase-page"

export default function Purchase() {
  return <PurchasePage />
}

